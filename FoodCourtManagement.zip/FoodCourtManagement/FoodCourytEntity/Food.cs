﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace FoodCourytEntity
{
    public class Food
    {
        [Key]

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int FoodId { get; set; }

        public string FoodName { get; set; }

        public string FoodType { get; set; }

        public int FoodCost { get; set; }
    }
}
