﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace FoodCourytEntity
{
   public class Sales
    {
        [Key]

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SalesId { get; set; }
        
        [ForeignKey("food")]
        public int FoodId { get; set; }

        public Food food { get; set; }

        public int FoodQuantiy { get; set; }

        public int SalesAmount { get; set; }
    }
}
