﻿using System;
using FoodCourytEntity;
using FoodCourtDAL;
using System.Collections.Generic;

namespace FoodCourtBLL
{
    public class FoodBLL
    {
        FoodDAL foodDALObj=new FoodDAL();

        public string AddFoodBLL(Food food)
        {


            string msg = foodDALObj.AddFoodDAL(food);
            return msg;
        }

        public string EditFoodBLL(Food food)
        {
            string msg = foodDALObj.EditFoodDAL(food);
            return msg;
        }

        public List<Food> ViewAllBll()
        {
            List<Food> list = foodDALObj.ViewAll();
                return list;

        }

        public List<Food>ViewByName(string FoodName)
        {
            List<Food> list = foodDALObj.ViewFoodbyname(FoodName);
            return list;
        }
    }
}
