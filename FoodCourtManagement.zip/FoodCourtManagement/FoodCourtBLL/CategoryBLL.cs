﻿using FoodCourtDAL;
using FoodCourytEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtBLL
{
    public class CategoryBLL
    {
        CategoryDAL CategoryDALObj = new CategoryDAL();

        public string AddCategoryBLL(Category Category)
        {


            string msg = CategoryDALObj.AddCatogaryDAL(Category);
            return msg;
        }

        public string EditCategoryBLL(Category Category)
        {
            string msg = CategoryDALObj.EditCategoryDAL(Category);
            return msg;
        }

        public List<Category> ViewAllBll()
        {
            List<Category> list = CategoryDALObj.ViewAll();
            return list;

        }

        public List<Category> ViewByName(string CategoryName)
        {
            List<Category> list = CategoryDALObj.ViewCategorybyname(CategoryName);
            return list;
        }
    }
}
