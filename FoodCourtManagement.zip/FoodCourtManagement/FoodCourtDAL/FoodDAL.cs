﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FoodCourtDAL.Migrations;
using FoodCourytEntity;
using Microsoft.EntityFrameworkCore;

namespace FoodCourtDAL
{


    public class FoodDAL
    {

        FoodContextDB db = null;



        public string AddFoodDAL(Food food)
        {
            db = new FoodContextDB();
            db.food.Add(food);
            db.SaveChanges();
            return "saved";
        }

        public string EditFoodDAL(Food food)
        {
            db = new FoodContextDB();
            db.Entry(food).State = EntityState.Modified;
            db.SaveChanges();
            return "updated";
        }

        public List<Food> ViewAll()
        {
            db = new FoodContextDB();
            List<Food> list = db.food.ToList();
            return list;
        }
        public List<Food> ViewFoodbyname(string FoodName)
        {
            db = new FoodContextDB();
            List<Food> list = db.food.ToList();

            //LINQ query select * from movie where movietype='type'
            var result = from obj in list
                         where obj.FoodName == FoodName
                         select obj;
            List<Food> foodResult = new List<Food>();
            foreach (var item in result)//linq query execution
            {
                foodResult.Add(item);
            }
            return foodResult;

        }





    }
}
