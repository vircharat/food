﻿using FoodCourytEntity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FoodCourtDAL
{
    public class CategoryDAL
    {


        FoodContextDB db = null;



        public string AddCatogaryDAL(Category category)
        {
            db = new FoodContextDB();
            db.categorie.Add(category);
            db.SaveChanges();
            return "saved";
        }

        public string EditCategoryDAL(Category category)
        {
            db = new FoodContextDB();
            db.Entry(category).State = EntityState.Modified;
            db.SaveChanges();
            return "updated";
        }

        public List<Category> ViewAll()
        {
            db = new FoodContextDB();
            List<Category> list = db.categorie.ToList();
            return list;
        }
        public List<Category> ViewCategorybyname(string CategoryName)
        {
            db = new FoodContextDB();
            List<Category> list = db.categorie.ToList();

            //LINQ query select * from movie where movietype='type'
            var result = from obj in list
                         where obj.CategoryName == CategoryName
                         select obj;
            List<Category> CategoryResult = new List<Category>();
            foreach (var item in result)//linq query execution
            {
                CategoryResult.Add(item);
            }
            return CategoryResult;

        }

    }
}
