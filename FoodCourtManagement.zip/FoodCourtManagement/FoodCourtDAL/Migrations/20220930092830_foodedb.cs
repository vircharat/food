﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FoodCourtDAL.Migrations
{
    public partial class foodedb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "food",
                columns: table => new
                {
                    FoodId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FoodName = table.Column<string>(nullable: true),
                    FoodType = table.Column<string>(nullable: true),
                    FoodCost = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_food", x => x.FoodId);
                });

            migrationBuilder.CreateTable(
                name: "categorie",
                columns: table => new
                {
                    CategoryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CategoryName = table.Column<string>(nullable: true),
                    FoodId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_categorie", x => x.CategoryId);
                    table.ForeignKey(
                        name: "FK_categorie_food_FoodId",
                        column: x => x.FoodId,
                        principalTable: "food",
                        principalColumn: "FoodId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sales",
                columns: table => new
                {
                    SalesId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FoodId = table.Column<int>(nullable: false),
                    FoodQuantiy = table.Column<int>(nullable: false),
                    SalesAmount = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_sales", x => x.SalesId);
                    table.ForeignKey(
                        name: "FK_sales_food_FoodId",
                        column: x => x.FoodId,
                        principalTable: "food",
                        principalColumn: "FoodId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_categorie_FoodId",
                table: "categorie",
                column: "FoodId");

            migrationBuilder.CreateIndex(
                name: "IX_sales_FoodId",
                table: "sales",
                column: "FoodId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "categorie");

            migrationBuilder.DropTable(
                name: "sales");

            migrationBuilder.DropTable(
                name: "food");
        }
    }
}
