﻿using Microsoft.EntityFrameworkCore;
using System;
using FoodCourytEntity;

namespace FoodCourtDAL
{
    public class FoodContextDB: DbContext
    {
        public DbSet<Food> food { get; set; }
        public DbSet<Sales> sales { get; set; }
        public DbSet<Category> categorie { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptionsBuilder)
        {
            dbContextOptionsBuilder.UseSqlServer("Data Source=VDC01LTC2179;Initial Catalog=FoodTable;Integrated Security=True;");
        }
    }
}
