﻿using FoodCourtBLL;
using FoodCourtDAL;
using FoodCourytEntity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagement
{
    public class CategoryPl
    {
        public void AddCategory()
        {
            Category category = new Category();
           
            Console.WriteLine("Enter Category Name : ");
            category.CategoryName = Console.ReadLine();

            Console.WriteLine("Enter Food Id");
            category.FoodId = Convert.ToInt32(Console.ReadLine());

            CategoryBLL categoryBLL = new CategoryBLL();    
           
            string msg = categoryBLL.AddCategoryBLL(category);
            Console.WriteLine(msg);
            
        }

        public void EditCategory()
        {
            Category Category = new Category();
            Console.WriteLine("Enter Category Name : ");
            Category.CategoryName = Console.ReadLine();
           
            Console.WriteLine("Enter Category Id : ");
            Category.CategoryId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Food Id");
            Category.FoodId = Convert.ToInt32(Console.ReadLine());
          
            CategoryBLL categoryBLL = new CategoryBLL();
           
            string msg = categoryBLL.EditCategoryBLL(Category);

            Console.WriteLine(msg);


        }

        public void ViewByCategoryName()
        {
            CategoryBLL CategoryBLLObj = new CategoryBLL();
            Console.WriteLine("Enter Category Name : ");
            string CategoryName = Console.ReadLine();

            List<Category> list = CategoryBLLObj.ViewByName(CategoryName);

            foreach (var item in list)
            {
                Console.WriteLine("-------------------");
                Console.WriteLine("Category Name : " + item.CategoryName);
                Console.WriteLine("Category id : " + item.CategoryId);
                Console.WriteLine("Food Id : " + item.FoodId);
            

            }
        }

        public void ViewAll()
        {
            CategoryBLL CategoryBLLObj = new CategoryBLL();


            List<Category> list = CategoryBLLObj.ViewAllBll();

            foreach (var item in list)
            {
                Console.WriteLine("-------------------");
                Console.WriteLine("Category Name : " + item.CategoryName);
                Console.WriteLine("Category id : " + item.CategoryId);
                Console.WriteLine("Food Id : " + item.FoodId);

            }

        }
    }
}
