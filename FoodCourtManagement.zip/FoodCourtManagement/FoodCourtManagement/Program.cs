﻿using System;
using FoodCourtBLL;

using FoodCourtDAL;

namespace FoodCourtManagement
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Valtech Food Court");
            AdminPL adminPLObj = new AdminPL();
            adminPLObj.menu();
        }
    }
}
