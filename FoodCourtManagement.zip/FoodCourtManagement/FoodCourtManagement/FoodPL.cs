﻿using System;
using System.Collections.Generic;
using System.Text;
using FoodCourytEntity;
using FoodCourtBLL;

namespace FoodCourtManagement
{
    public class FoodPL
    {

        public void AddFood()
        {
            Food food = new Food();
            Console.WriteLine("Enter Food Name : ");
            food.FoodName = Console.ReadLine();
           
            Console.WriteLine("Enter Food Type veg or non veg");
            food.FoodType = Console.ReadLine();
            Console.WriteLine("Enter Food Cost");
            food.FoodCost = Convert.ToInt32(Console.ReadLine());
            FoodBLL foodBLLObj = new FoodBLL();
            string msg = foodBLLObj.AddFoodBLL(food);

            Console.WriteLine(msg);

        }

        public void EditFood()
        {
            Food food = new Food();
            Console.WriteLine("Enter Food Name : ");
            food.FoodName = Console.ReadLine();
            Console.WriteLine("Enter Food Id : ");
            food.FoodId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Food Type veg or non veg");
            food.FoodType = Console.ReadLine();
            Console.WriteLine("Enter Food Cost");
            food.FoodCost = Convert.ToInt32(Console.ReadLine());
            FoodBLL foodBLLObj = new FoodBLL();
            string msg = foodBLLObj.EditFoodBLL(food);

            Console.WriteLine(msg);


        }

        public void ViewByFoodName()
        {
            FoodBLL foodBLLObj = new FoodBLL();
            Console.WriteLine("Enter Food Name : ");
            string FoodName = Console.ReadLine();

            List<Food>list=foodBLLObj.ViewByName(FoodName);
            
            foreach(var item in list)
            {
                Console.WriteLine("-------------------");
                Console.WriteLine("Food Name : "+item.FoodName);
                Console.WriteLine("Food id : " + item.FoodId);
                Console.WriteLine("Food Type : " + item.FoodType);
                Console.WriteLine("Food Cost : " + item.FoodCost);

            }
        }

        public void ViewAll()
        {
            FoodBLL foodBLLObj = new FoodBLL();
         

            List<Food> list = foodBLLObj.ViewAllBll();
           
            foreach (var item in list)
            {
                Console.WriteLine("-------------------");
                Console.WriteLine("Food Name : " + item.FoodName);
                Console.WriteLine("Food id : " + item.FoodId);
                Console.WriteLine("Food Type : " + item.FoodType);
                Console.WriteLine("Food Cost : " + item.FoodCost);

            }

        }
        
    }
    
}
