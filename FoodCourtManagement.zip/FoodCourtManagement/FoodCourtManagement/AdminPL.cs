﻿using FoodCourtBLL;
using System;
using System.Collections.Generic;
using System.Text;

namespace FoodCourtManagement
{
    public class AdminPL
    {
        public void menu()
        {
            Console.WriteLine(
             "1)Press 1 to login as Admin\n" +
            
             "2)Press 2 to Exit");

            int codeentered;
            codeentered = Convert.ToInt32(Console.ReadLine());

            switch (codeentered)
            {
                case 1:
                    AdminPL adminPLObj = new AdminPL();
                    adminPLObj.AdminLogin();
                    break;
                case 2:

                    break;
            
                default:
                    Console.WriteLine("Invalid Code");
                    break;
            }

        }
        public void AdminLogin()
        {
            string AdminEmail;
            string AdminPassword;
            Console.Write("Email :");
            AdminEmail = Console.ReadLine();
            Console.Write("Password :");
            AdminPassword = Console.ReadLine();
            AdminBLL adminBLLObj = new AdminBLL();

            bool flag = adminBLLObj.AdminLogin(AdminEmail, AdminPassword);
            if (flag)
            {
                Console.WriteLine("Logged in Successfully as admin");
                AdminPL adminPL = new AdminPL();
                adminPL.AdminSection();
                

            }
            else
            {
                Console.WriteLine("Invalid credentials");
            }

        }

        public void AdminSection()
        {
            Console.WriteLine(
             "1)Press 1 to go to Food Section\n" +

             "2)Press 2 to go to Category Section\n" +

             "3) Press 3 to go to Sales Section \n" +
            
             "4)Press 4 to exit");

            int codeentered;
            codeentered = Convert.ToInt32(Console.ReadLine());
            AdminPL adminPLObj = new AdminPL();
            bool flag = true;

            switch (codeentered)
            {  
                case 1:
                    while (flag)
                    {


                        flag=adminPLObj.foodsection();

                    }
                    break;
                case 2:
                    while (flag)
                    {

                        adminPLObj.categorysection();
                    }
                    break;
                case 3:
                    adminPLObj.sales_section();
                    break;
                case 4:

                    break;
                default:
                    Console.WriteLine("Invalid Code");
                    break;


            }

        }

        public bool foodsection()
        {
            Console.WriteLine("-----------------------------------------------------------------------------------------\n" +
                "-----------------------------------------------------------------------------------------");
            Console.WriteLine(
            "1)Press 1 to add food\n" +

            "2)Press 2 to edit food\n" +

            "3) Press 3  view food details by name\n" +

            "4)Press 4  view all food");

            int codeentered;
            codeentered = Convert.ToInt32(Console.ReadLine());
            FoodPL foodPLObj = new FoodPL();

            switch (codeentered)
            {
                case 1:

                    foodPLObj.AddFood();
                    break;
                case 2:
                    foodPLObj.EditFood();
                    break;
                case 3:
                    foodPLObj.ViewByFoodName();
                    break;
                case 4:
                    foodPLObj.ViewAll();
                    break;
                case 5:
                    return false;
                    break;
                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
            return true;
        }
        public bool categorysection()
        {

            Console.WriteLine("-----------------------------------------------------------------------------------------\n" +
                "-----------------------------------------------------------------------------------------");
            Console.WriteLine(
            "1)Press 1 to add Category\n" +

            "2)Press 2 to edit Category\n" +

            "3) Press 3  view Category details by name\n" +

            "4)Press 4  view all Category");

            int codeentered;
            codeentered = Convert.ToInt32(Console.ReadLine());
            CategoryPl CategoryPLObj = new CategoryPl();

            switch (codeentered)
            {
                case 1:

                    CategoryPLObj.AddCategory();
                    break;
                case 2:
                    CategoryPLObj.EditCategory();
                    break;
                case 3:
                    CategoryPLObj.ViewByCategoryName();
                    break;
                case 4:
                    CategoryPLObj.ViewAll();
                    break;
                case 5:
                    return false;
                    break;
                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
            return true;


        }

        public void sales_section()
        {
            
        }


    }
}
